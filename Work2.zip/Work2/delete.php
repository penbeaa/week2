<?php

try
{

	include"config/dbconfig.php";
	$id = isset($_GET['id']) ? $_GET['id'] : die("ERROR:Record ID not found.!");
	echo $id;


	$query = "DELETE FROM customers WHERE CUSTOMER_ID = ?";
	$stmt = $conn->prepare($query);
	$stmt ->bindValue(1, $id);

	if ($stmt->execute())
	{
		header("Location: index.php");
	}
}

catch(PDOException $e)
	{
    echo "ERROR :" .$e->getMessage();
	}



?>