<?php 
$msg = "";
$errors = [];

function sanitizeInput($data)
{

    $data = stripcsLashes($data);
    $data = htmlspecialchars($data);
    $data = trim($data);

    return $data;
}

function validateInput($data, $patterns)
{
    return preg_match($patterns, $data);
}



$patterns = [

        "CUSTOMER_ID" => "/^[a-zA-Z\s]{1,25}$/", 
        "STORE_ID" => "/^[a-zA-Z\s]{1,20}$/",
        "FIRST_NAME" => "/^[a-zA-Z0-9\s,#,-]{1,200}$/",
        "FIRST_NAME" => "/^[a-zA-Z\s]{1,20}$/",
        "EMAIL" => "/^[a-zA-Z0-9\s]{1,20}$/",
        "ADDRESS" => "/^[a-zA-Z0-9\s,#,-]{1,200}$/",


            ];



if($_SERVER['REQUEST_METHOD'] == "POST")
{
    
    $CUSTOMER_ID    = sanitizeInput($_POST['CUSTOMER_ID']);
    $STORE_ID       = sanitizeInput($_POST['STORE_ID']);
    $FIRST_NAME     = sanitizeInput($_POST['FIRST_NAME']);
    $LAST_NAME      = sanitizeInput($_POST['LAST_NAME']);
    $EMAIL          = sanitizeInput($_POST['EMAIL ']);
    $ADDRESS        = sanitizeInput($_POST['ADDRESS ']);

    if (!validateInput($CUSTOMER_ID, $patterns['CUSTOMER_ID'] ))
    {
        $errors['CUSTOMER_ID'] = "Invalid Customer ID";
    }

    if (!validateInput($STORE_ID, $patterns['STORE_ID'] ))
    {
        $errors['CUSTOMER_ID'] = "Invalid Store ID";
    }

    if (!validateInput($FIRST_NAME, $patterns['FIRST_NAME'] ))
    {
        $errors['FIRST_NAME'] = "Invalid First Name";

    }

    if (!validateInput($LAST_NAME, $patterns['LAST_NAME'] ))
    {
        $errors['LAST_NAME'] = "Invalid Last Name";
        
    }

    if (!validateInput($EMAIL, $patterns['EMAIL'] ))
    {
        $errors['EMAIL'] = "Invalid Email";
        
    }

    if (!validateInput($ADDRESS, $patterns['ADDRESS'] ))
    {
        $errors['ADDRESS'] = "Invalid Address";
        
    }

    if (empty($errors))
    {

    try 
    {

        include"config/dbconfig.php";


        $query = "UPDATE customers SET CUSTOMER_ID = ?, STORE_ID = ?, FIRST_NAME = ?, LAST_NAME = ?, EMAIL = ?, ADDRESS = ? WHERE CustomerID= ?";
 

        $stmt = $conn->prepare($query);

        $stmt->bindValue(1, $CUSTOMER_ID);
        $stmt->bindValue(2, $STORE_ID);
        $stmt->bindValue(3, $FIRST_NAME);
        $stmt->bindValue(4, $LAST_NAME);
        $stmt->bindValue(5, $EMAIL);
        $stmt->bindValue(6, $ADDRESS);
        $stmt->bindValue(7, $id);

        if($stmt->execute())
         {
             $msg = ' <div class="alert alert-success"><strong>Record was saved.!!</strong> </div>';
         }
    
        else
         {
            $msg = ' <div class="alert alert-danger"><strong>Unable to save record.!!</strong> </div>';
         }
    }

            catch(Exception $e)
            {
          echo "Error :" .$e->getMessage();
           }

     }
    }



?>


<!DOCTYPE html>
<html>
<head>

	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <title>Add Cutomer Info</title>
 </head>
 <body>
    <div class="container mt-5 d-flex justify-content-center">
        <div class="card w-50">
            <div class="card-body">
            <?php echo $msg; ?>

                <form action="#" method="POST">

                    <div class="form-group mt-2">
                        <label for="CUSTOMER_ID">Customer ID:</label>
                        <input type="texty" class="form-control" name="CUSTOMER_ID" value="<?php echo $CUSTOMER_ID ?>">
                        <span class = "text-danger"><?php echo $errors['CUSTOMER_ID'] ?? ''; ?></span>
                    </div>
                    <div class="form-group mt-2">
                        <label for="STORE_ID">Store ID:</label>
                        <input type="texty" class="form-control" name="STORE_ID" value="<?php echo $STORE_ID ?>">
                        <span class = "text-danger"><?php echo $errors['STORE_ID'] ?? ''; ?></span>
                    </div>
                    <div class="form-group mt-2">
                        <label for="FIRST_NAME">Fisrt Name:</label>
                        <input type="texty" class="form-control" name="FIRST_NAME" value="<?php echo $FIRST_NAME ?>" >
                        <span class = "text-danger"><?php echo $errors['FIRST_NAME'] ?? ''; ?></span>
                    </div>
                    <div class="form-group mt-2">
                        <label for="LAST_NAME">Last Name:</label>
                        <input type="texty" class="form-control" name="LAST_NAME" value="<?php echo $LAST_NAME ?>">
                        <span class = "text-danger"><?php echo $errors['LAST_NAME'] ?? ''; ?></span>
                    </div>
                    <div class="form-group mt-2">
                        <label for="EMAIL">Email:</label>
                        <input type="texty" class="form-control" name="EMAIL" value="<?php echo $EMAIL ?>">
                        <span class = "text-danger"><?php echo $errors['EMAIL'] ?? ''; ?></span>
                    </div>
                    <div class="form-group mt-2">
                        <label for="ADDRESS">Address:</label>
                        <input type="texty" class="form-control" name="ADDRESS" value="<?php echo $ADDRESS ?>">
                        <span class = "text-danger"><?php echo $errors['ADDRESS'] ?? ''; ?></span>
                    </div>

                      <div class="form-group mt-2 d-flex justify-content-center">
                        <button class="btn btn-primary">Add</button>
                        <a href="index.php" class="btn btn-danger ms-2">Cancel</a>

                    </form>
             </div>
         </div>
    </div>


 </body>
 </html>