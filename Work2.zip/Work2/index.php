<?php 

include"config/dbconfig.php";
$query = "SELECT * FROM customers";
$stmt = $conn->prepare($query); 
$stmt-> execute();

?>

<!DOCTYPE html>
<html>
<head>


<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/datatables.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<title> Table Data</title>
</head>

<body>
<div class="container mt-3">
  <table class="table table-stripped text-center">
    <thead>
        <tr>
          <th>CUSTOMER ID </th>
          <th>STORE ID    </th>
          <th>FIRST NAME  </th>
          <th>LAST NAME   </th>
          <th>EMAIL       </th>
          <th>ADDRESS     </th>
          <th>ACTION      </th>
        </tr>
    </thead>

    <tbody>
      <?php 

      include "config/dbconfig.php"; 

      
      $query = "SELECT CUSTOMER_ID, STORE_ID, FIRST_NAME, LAST_NAME, EMAIL, ADDRESS FROM customers";

     
      $stmt = $conn->prepare($query);

  
      $stmt->execute();
        while ($row = $stmt->fetch(PDO :: FETCH_ASSOC))
        {
          extract($row);

          echo "<tr>
               <td>$CUSTOMER_ID</td>
               <td>$STORE_ID</td>
               <td>$FIRST_NAME</td>
               <td>$LAST_NAME</td>
               <td>$EMAIL</td>
               <td>$ADDRESS</td>
               <td>
               
          <button type='button' class='btn btn-info btn btn-sm'>info</button>
          <a href='edit.php?id={$CUSTOMER_ID}' class='btn btn-warning btn btn-sm'>Edit</button>
          <a href='#' onclick='delete_user({$CUSTOMER_ID});' class='btn btn-danger btn btn-sm'>Delete</a>
      </tr>";
        }

      ?>



    </tbody>
  </table>


</div>



   <script  src="js/jquery.min.js"></script>
   <script  src="js/bootstrap.bundle.min.js"></script>
   <script  src="js/datatables.min.js"></script>
   

   <script>

    $(document).ready(function()
    {
      $('table').DataTable
      ({

        order:[0, 'desc']

        });

    } );

  function delete_user(id)
  {
    let answer = confirm( "Are you sure ? ")
    if (answer)
    {
      window.location= "delete.php?id="+id;
    }
  }

   </script>
 </body>
 </html>