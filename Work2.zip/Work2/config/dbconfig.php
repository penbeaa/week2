<?php

$host     = "localhost";
$dbName   = "database2";
$userName = "root";
$password = "";


try 
{
	$conn = new PDO("mysql:host={$host}; dbname={$dbName};", $userName, $password);
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	# SETATTRIBUTE is used to set various attributes on the PDO object 
	# PDO attr_errmode is the attribute that defines that error handling mode
	#PDO : errmode_exeption ensures that errors throw exceptions instead of just warning or silent 
 	// ECHO"CONNECTION SUCCESSFULLY"



}

catch (exception $e)
{
	echo "ERROR: " .$e->getMessage();

}


?>